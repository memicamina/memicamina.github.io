<?php
include 'connect.php';

if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
}

if (isset($_GET['deleteid'])) {
    $deleteId = $_GET['deleteid'];

    $sql = "DELETE FROM `biljka` WHERE naziv = '$deleteId'";
    $result = mysqli_query($con, $sql);

    if ($result) {
        header('Location: display.php'); // Promijeni putanju na stvarnu putanju do stranice sa popisom softvera
        exit();
    } else {
        echo 'Greška prilikom brisanja softvera: ' . mysqli_error($con);
    }
}
?>