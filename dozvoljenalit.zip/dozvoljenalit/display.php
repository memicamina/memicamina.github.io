
<?php

$sql = "SELECT * FROM `biljka`";
$result = mysqli_query($con, $sql);

if ($result) {
    while ($row = mysqli_fetch_assoc($result)) {
        $naziv = $row['naziv'];
        $slika = $row['slika'];
        
        // <a href="delete.php?deleteid=' . $naziv . '">Delete</a>

    }
}

?>