<?php
include 'connect.php';

if(isset($_POST['submit'])){
    $naziv = $_POST['naziv'];
    $slika = $_POST['slika'];


    $sql = "INSERT INTO `biljka` (naziv, slika, latinskinaziv, opis) VALUES ('$naziv', '$slika', '$latinskinaziv', '$opis')";

    $result = mysqli_query($con, $sql);

    if($result){
        //echo "Data inserted successfully";
        header('location:display.php');
    } else {
        die(mysqli_error($con));
    }
}
?>