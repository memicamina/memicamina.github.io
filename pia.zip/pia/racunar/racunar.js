class Racunar {
  constructor(naziv, kategorija, tip, ram, graficka, opis, url) {
    this.naziv = naziv;
    this.kategorija = kategorija;
    this.tip = tip;
    this.ram = ram;
    this.graficka = graficka;
    this.opis = opis;
    this.url = url;
  }

  prikazi(id) {
    var div0 = document.createElement("div");
    var div1 = document.createElement("div");
    var div2 = document.createElement("div");

    var h2 = document.createElement("h2");
    h2.innerHTML = "naziv" + this.naziv;

    var ul = document.createElement("ul");
    var li1 = document.createElement("li");
    var li2 = document.createElement("li");
    var li3 = document.createElement("li");
    var li4 = document.createElement("li");
    li1.innerHTML = "kategorija" + this.kategorija;
    li2.innerHTML = "tip procesora" + this.tip;
    li3.innerHTML = "ram kategorija" + this.ram;
    li4.innerHTML = "graficka" + this.graficka;
    var img = document.createElement("img");
    img.src = this.url;

    var p = document.createElement("p");
    p.innerHTML = "kratak opis" + this.opis;
    ul.appendChild(li1);
    ul.appendChild(li2);
    ul.appendChild(li3);
    ul.appendChild(li4);
    div0.appendChild(h2);
    div1.appendChild(img);
    div1.appendChild(ul);
    div2.appendChild(p);
    var iddiv = document.getElementById(id);
    iddiv.appendChild(div0);
    iddiv.appendChild(div1);
    iddiv.appendChild(div2);

    div0.style.width = "400px";
    div0.style.height = "50px";
    div0.style.border = "0px";

    div1.style.display = "flex";
    div2.style.border = "1px solid black";
    div2.style.margin = "20px";
    div2.style.padding = "5px";
    iddiv.style.width = "600px";
    iddiv.style.border = "2px solid black";

    img.style.border = "2px solid black";
  }
}

var rac1 = new Racunar(
  "Lenovo ThinkPad T590",
  "Laptop",
  "8th Gen Intel® Core™ i7 processor",
  "8GB of RAM",
  "ThinkPad E490",
  "Unburden your productivity beast. Dual far-field noise-cancelling microphones. Keyboard with number keypad. Great security features. Long battery life, and the availability of global LTE-A connectivity",
  "laptop.png"
);

var rac2 = new Racunar(
  "Lenovo ThinkPad T590",
  "Laptop",
  "8th Gen Intel® Core™ i7 processor",
  "8GB of RAM",
  "ThinkPad E490",
  "Unburden your productivity beast. Dual far-field noise-cancelling microphones. Keyboard with number keypad. Great security features. Long battery life, and the availability of global LTE-A connectivity",
  "laptop.png"
);

var rac3 = new Racunar(
  "Lenovo ThinkPad T590",
  "Laptop",
  "8th Gen Intel® Core™ i7 processor",
  "8GB of RAM",
  "ThinkPad E490",
  "Unburden your productivity beast. Dual far-field noise-cancelling microphones. Keyboard with number keypad. Great security features. Long battery life, and the availability of global LTE-A connectivity",
  "laptop.png"
);

var rac4 = new Racunar(
  "Lenovo ThinkPad T590",
  "Laptop",
  "8th Gen Intel® Core™ i7 processor",
  "8GB of RAM",
  "ThinkPad E490",
  "Unburden your productivity beast. Dual far-field noise-cancelling microphones. Keyboard with number keypad. Great security features. Long battery life, and the availability of global LTE-A connectivity",
  "laptop.png"
);

var rac5 = new Racunar(
  "Lenovo ThinkPad T590",
  "Laptop",
  "8th Gen Intel® Core™ i7 processor",
  "8GB of RAM",
  "ThinkPad E490",
  "Unburden your productivity beast. Dual far-field noise-cancelling microphones. Keyboard with number keypad. Great security features. Long battery life, and the availability of global LTE-A connectivity",
  "laptop.png"
);
rac1.prikazi("racunar1");
rac2.prikazi("racunar2");
rac3.prikazi("racunar3");
rac4.prikazi("racunar4");
rac5.prikazi("racunar5");
