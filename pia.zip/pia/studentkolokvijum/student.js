class Student {
  constructor(ime, prezime, razred, urslika, predmeti = [], ocene = []) {
    this.ime = ime;
    this.prezime = prezime;
    this.razred = razred;
    this.urslika = urslika;
    this.predmeti = predmeti;
    this.ocene = ocene;
  }
  prikaz(id) {
    var glavni = document.getElementById(id);
    var deo = document.createElement("div");
    var deo1 = document.createElement("div");
    var deo2 = document.createElement("div");
    var deo11 = document.createElement("div");
    var deo12 = document.createElement("div");
    var deo13 = document.createElement("div");
    deo11.style.border = "1px solid black";
    deo12.style.border = "1px solid black";
    deo13.style.border = "1px solid black";
    deo2.style.border = "1px solid black";
    deo1.style.width = "250px";
    var img = document.createElement("img");
    img.src = this.urslika;
    img.style.width = "150px";
    img.style.height = "150px";
    deo2.appendChild(img);
    deo2.style.width = "400px";
    var p = document.createElement("p");
    var p1 = document.createElement("p");
    p.innerHTML = " ime i prezime " + this.ime + " " + this.prezime;
    p1.innerHTML = " razred " + this.razred;
    deo11.appendChild(p), deo12.appendChild(p1);
    deo1.appendChild(deo11);
    deo1.appendChild(deo12);
    for (let i = 0; i < this.predmeti.length; i++) {
      var t = document.createElement("p");
      t.innerHTML = " predmet " + this.predmeti[i] + " " + this.ocene[i];
      deo13.appendChild(t);
    }
    deo1.appendChild(deo13);
    deo.appendChild(deo1);
    deo.appendChild(deo2);
    deo.style.display = "flex";
    glavni.appendChild(deo);
  }
}

student = new Student(
  "Edina",
  "Kucevic",
  "3",
  "https://media.istockphoto.com/photos/facing-my-future-with-confidence-picture-id1139495117?b=1&k=20&m=1139495117&s=612x612&w=0&h=lmJ-LbvRQ87kDzeX0TVHX87thzkYxVsdT8oN1LXQ5fE=",
  ["eng", "fran", "srp", "mat"],
  [5, 5, 4, 4]
);
student.prikaz("glavni");

student1 = new Student(
  "Edina",
  "Kucevic",
  "3",
  "https://media.istockphoto.com/photos/facing-my-future-with-confidence-picture-id1139495117?b=1&k=20&m=1139495117&s=612x612&w=0&h=lmJ-LbvRQ87kDzeX0TVHX87thzkYxVsdT8oN1LXQ5fE=",
  ["eng", "fran", "srp", "mat"],
  [5, 5, 4, 4]
);
student1.prikaz("glavni");
