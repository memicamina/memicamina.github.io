class Knjiga {
  constructor(
    id,
    naziv,
    autor,
    izdavac,
    godina,
    opis,
    cena,
    urlslike1,
    urlslike2
  ) {
    this.id = id;
    this.naziv = naziv;
    this.autor = autor;
    this.izdavac = izdavac;
    this.opis = opis;
    this.cena = cena;
    this.godina = godina;
    this.urlslike1 = urlslike1;
    this.urlslike2 = urlslike2;
  }
  prikazi() {
    var glavni = document.getElementById("glavni");
    var naziv = document.createElement("div");
    var btn = document.createElement("button");
    btn.innerHTML = "+";
    var detalji = document.createElement("div");
    var detalji1 = document.createElement("div");
    var detalj2 = document.createElement("div");
    var opis = document.createElement("div");
    var p = document.createElement("p");
    p.innerHTML = this.id + " " + this.naziv;
    naziv.appendChild(p);
    naziv.appendChild(btn);
    glavni.appendChild(naziv);
    detalji.style.display = "flex";
    var p1 = document.createElement("p");
    var p2 = document.createElement("p");
    var p3 = document.createElement("p");
    var p4 = document.createElement("p");
    p1.innerHTML = this.autor;
    p2.innerHTML = this.izdavac;
    p3.innerHTML = this.godina;
    p4.innerHTML = this.cena;
    detalji1.appendChild(p1);
    detalji1.appendChild(p2);
    detalji1.appendChild(p3);
    detalji1.appendChild(p4);
    detalji.appendChild(detalji1);
    var img = document.createElement("img");
    img.style.width = "100px";
    img.style.height = "100px";
    img.src = this.urlslike1;
    detalj2.appendChild(img);

    var dugmici = document.createElement("div");
    var btn1 = document.createElement("button");
    var btn2 = document.createElement("button");
    btn1.innerHTML = "<<";
    btn2.innerHTML = ">>";

    dugmici.appendChild(btn1);
    dugmici.appendChild(btn2);
    detalj2.appendChild(dugmici);
    detalji.appendChild(detalj2);
    opis.innerHTML = "<p>" + this.opis + "</p>";
    glavni.appendChild(detalji);
    glavni.appendChild(opis);
    // ovo je funkcija kao za dodavanje i ono brisanje
    btn.onclick = () => {
      if (btn.innerHTML == "+") {
        btn.innerHTML = "-";
        detalji.style.display = "none";
      } else if (btn.innerHTML == "-") {
        btn.innerHTML = "+";
        detalji.style.display = "flex";
      }
    };
    btn1.onclick = () => {
      img.src = this.urlslike2;
    };
    btn2.onclick = () => {
      img.src = this.urlslike1;
    };
  }
}

class Lista {
  constructor() {
    this.knjige = [];
  }
  dodajknjigu(knjiga) {
    this.knjige.push(knjiga);
  }
  prikaziknjigu() {
    for (let i = 0; i < this.knjige.length; i++) {
      this.knjige[i].prikazi();
    }
  }
  odstampajcenuknjige() {
    let s = 0;
    for (let i = 0; i < this.knjige.length; i++) {
      s += this.knjige[i].cena;
    }
    var glavni = document.getElementById("glavni");
    var p = document.createElement("p");
    p.innerHTML = "cena svih knjiga je " + s;
    glavni.appendChild(p);
  }

  sortirajpoceni() {
    var glavni = document.getElementById("glavni");
    while (glavni.firstChild != null) {
      glavni.removeChild(glavni.lastChild);
    }
    this.knjige.sort((a, b) => a.cena - b.cena);
    for (let i = 0; i < this.knjige.length; i++) {
      this.knjige[i].prikazi();
    }
  }
}

knjiga11 = new Knjiga(
  "1",
  "Naziv1",
  "Autor1",
  "Izdavac1",
  "2010",
  "Opis....",
  1000,
  "http://www.centarzaafirmacijuirazvoj.org/wp-content/uploads/2022/09/The-Ukrainian-Book-Institute-Purchases-380.9-Thousand-Books-for-Public-Libraries1.jpeg",
  "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQn9cyNQgQG3majbYZKIR6KYzRsWZB1c4OzrpLUo2n_bPNLpW4QaAb2JSjpB5X1ydamoog&usqp=CAU"
);
knjiga2 = new Knjiga(
  "2",
  "Naziv2",
  "Autor2",
  "Izdavac2",
  "2011",
  "Opis2....",
  1200,
  "https://img.freepik.com/premium-photo/opened-book-bible-background_112554-164.jpg?w=360",
  "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQn9cyNQgQG3majbYZKIR6KYzRsWZB1c4OzrpLUo2n_bPNLpW4QaAb2JSjpB5X1ydamoog&usqp=CAU"
);
knjiga3 = new Knjiga(
  "3",
  "Naziv3",
  "Autor3",
  "Izdavac3",
  "2012",
  "Opis3....",
  1500,
  "https://img.freepik.com/premium-photo/opened-book-bible-background_112554-164.jpg?w=360",
  "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQn9cyNQgQG3majbYZKIR6KYzRsWZB1c4OzrpLUo2n_bPNLpW4QaAb2JSjpB5X1ydamoog&usqp=CAU"
);
knjiga4 = new Knjiga(
  "4",
  "Naziv4",
  "Autor4",
  "Izdavac4",
  "2013",
  "Opis4....",
  1150,
  "https://img.freepik.com/premium-photo/opened-book-bible-background_112554-164.jpg?w=360",
  "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQn9cyNQgQG3majbYZKIR6KYzRsWZB1c4OzrpLUo2n_bPNLpW4QaAb2JSjpB5X1ydamoog&usqp=CAU"
);
knjiga1 = new Lista();
knjiga1.dodajknjigu(knjiga11);
knjiga1.dodajknjigu(knjiga2);
knjiga1.dodajknjigu(knjiga3);
knjiga1.dodajknjigu(knjiga4);
knjiga1.prikaziknjigu();
knjiga1.sortirajpoceni();
knjiga1.odstampajcenuknjige();
