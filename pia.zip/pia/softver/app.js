class Softver {
  constructor(naziv, kategorija, verzija, opis, url) {
    this.naziv = naziv;
    this.kategorija = kategorija;
    this.verzija = verzija;

    this.opis = opis;
    this.url = url;
  }

  prikazi(id) {
    var div0 = document.createElement("div");
    var div1 = document.createElement("div");
    var div2 = document.createElement("div");
    var h2 = document.createElement("h2");
    h2.innerHTML = "naziv" + this.naziv;

    var ul = document.createElement("ul");
    var li1 = document.createElement("li");
    var li2 = document.createElement("li");

    li1.innerHTML = "kategorija" + this.kategorija;
    li2.innerHTML = "verzija" + this.verzija;

    var img = document.createElement("img");
    img.src = this.url;
    var p = document.createElement("p");
    p.innerHTML = "kratak opis" + this.opis;
    ul.appendChild(li1);
    ul.appendChild(li2);
    var div3 = document.createElement("div");
    div3.style.border = "2px dashed black";
    div0.appendChild(h2);
    div1.appendChild(img);
    div3.appendChild(ul);
    div1.appendChild(div3);
    div2.appendChild(p);

    var iddiv = document.getElementById(id);
    iddiv.appendChild(div0);
    iddiv.appendChild(div1);
    iddiv.appendChild(div2);

    div1.style.display = "flex";
    div2.style.border = "1px solid black";
    div2.style.margin = "20px";
    div2.style.padding = "5px";
    iddiv.style.width = "600px";
    iddiv.style.border = "2px solid black";

    img.style.border = "2px solid black";
  }
}
var sof1 = new Softver(
  "Lenovo ThinkPad T590",
  "Softver",
  "8th Gen Intel® Core™ i7 processor",
  "8GB of RAM",
  "soff.png"
);

var sof2 = new Softver(
  "Lenovo ThinkPad T590",
  "Softver",
  "8th Gen Intel® Core™ i7 processor",
  "8GB of RAM",
  "soff.png"
);

var sof3 = new Softver(
  "Lenovo ThinkPad T590",
  "Softver",
  "8th Gen Intel® Core™ i7 processor",
  "8GB of RAM",
  "soff.png"
);

var sof4 = new Softver(
  "Lenovo ThinkPad T590",
  "Softver",
  "8th Gen Intel® Core™ i7 processor",
  "8GB of RAM",
  "soff.png"
);

var sof5 = new Softver(
  "Lenovo ThinkPad T590",
  "Softver",
  "8th Gen Intel® Core™ i7 processor",
  "8GB of RAM",
  "soff.png"
);
sof1.prikazi("softver1");
sof2.prikazi("softver2");
sof3.prikazi("softver3");
sof4.prikazi("softver4");
sof5.prikazi("softver5");
