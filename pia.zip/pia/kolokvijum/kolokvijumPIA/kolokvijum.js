class MobilbiTelefon {
  constructor(
    Sifra,
    Brend,
    Ekran,
    ZadnjaKamera,
    PrednjaKamera,
    RamMemorija,``
    Procesor,
    urlSlike
  ) {
    this.Sifra = Sifra;
    this.Brend = Brend;
    this.Ekran = Ekran;
    this.ZadnjaKamera = ZadnjaKamera;
    this.PrednjaKamera = PrednjaKamera;
    this.RamMemorija = RamMemorija;
    this.Procesor = Procesor;
    this.urlSlike = urlSlike;
  }

  Display() {
    var glavni = document.getElementById("glavni");
    var div = document.createElement("div");
    var img = document.createElement("img");
    var detalji = document.createElement("div");
    img.src = this.urlSlike;
    img.style.width = "200px";
    img.style.height = "200px";
    div.appendChild(img);
    detalji.innerHTML =
      "<p>Sifra: " +
      this.Sifra +
      "</p><p>Brend:" +
      this.Brend +
      "</p><p>Ekran:" +
      this.Ekran +
      "</p><p>Zadnja Kamera: " +
      this.ZadnjaKamera +
      "</p><p>Prednja Kamera: " +
      this.PrednjaKamera +
      "</p><p>Ram Memorija:" +
      this.RamMemorija +
      "</p><p>Procesor:" +
      this.Procesor +
      "</p>";
    div.appendChild(detalji);
    div.style.border = "1px solid black";
    div.style.width = "300px";
    div.style.height = "500px";
    glavni.appendChild(div);
  }
}

class Lista {
  constructor() {
    this.lista = [];
  }
  dodajulistu(telefon) {
    this.lista.push(telefon);
  }
  prikazilistu() {
    this.lista.forEach((element) => {
      element.Display();
    });
  }
}
telefon1 = new MobilbiTelefon(
  1,
  "samsung",
  "6.5",
  "63",
  "32",
  "6gb",
  "octa",
  "https://img.gigatron.rs/img/products/large/image6474921941bb6.jpg"
);
telefon2 = new MobilbiTelefon(
  1,
  "samsung",
  "6.5",
  "63",
  "32",
  "6gb",
  "octa",
  "https://img.gigatron.rs/img/products/large/image6474921941bb6.jpg"
);
telefon3 = new MobilbiTelefon(
  1,
  "samsung",
  "6.5",
  "63",
  "32",
  "6gb",
  "octa",
  "https://img.ep-cdn.com/images/500/500/wo/woktamfisduexjrycgqh.jpg"
);
telefon4 = new MobilbiTelefon(
  1,
  "samsung",
  "6.5",
  "63",
  "32",
  "6gb",
  "octa",
  "https://img.gigatron.rs/img/products/large/image6474921941bb6.jpg"
);
telefon5 = new MobilbiTelefon(
  1,
  "samsung",
  "6.5",
  "63",
  "32",
  "6gb",
  "octa",
  "https://img.gigatron.rs/img/products/large/image6474921941bb6.jpg"
);

var listatelefona = new Lista();
listatelefona.dodajulistu(telefon1);
listatelefona.dodajulistu(telefon2);
listatelefona.dodajulistu(telefon3);
listatelefona.dodajulistu(telefon4);
listatelefona.dodajulistu(telefon5);
listatelefona.prikazilistu();
