<?php
$suma = 0;
echo "porucili ste".$_POST['kolacici'] ."<br>";
echo "ukljucujuci i svijece" .$_POST['candle']."<br>";
echo "kao i " .$_POST['inscription'] ."<br>";
    $suma += $_POST['kolacici'];
if(isset($_POST['candle']))
$suma += $_POST['candle'];
if(isset($_POST['inscription']))
$suma += $_POST['inscription'];

echo "cena torte jeste:" .$suma;

?>