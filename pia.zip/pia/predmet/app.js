class Odevnipredmeti {
  constructor(id, naziv, slika, tip, cena, kolekcija) {
    this.id = id;
    this.naziv = naziv;
    this.slika = slika;
    this.tip = tip;
    this.cena = cena;
    this.kolekcija = kolekcija;
  }

  prikaz() {
    var ididv = document.getElementById("odevnipredmeti");
    var div = document.createElement("div");
    div.style.border = "2px solid black";
    div.style.width = "500px";
    div.style.margin = "20px";
    div.style.padding = "20px";

    var img = document.createElement("img");
    img.src = this.slika;
    img.style.width = "500px";
    img.style.height = "300px";

    var div1 = document.createElement("div");
    div1.style.width = "500px";
    div1.style.height = "300px";
    div1.style.border = "2px solid black";
    div1.appendChild(img);

    var ul = document.createElement("ul");
    var li1 = document.createElement("li");
    var li2 = document.createElement("li");
    var li3 = document.createElement("li");
    var li4 = document.createElement("li");
    var li5 = document.createElement("li");

    li1.innerHTML = "id" + this.id;
    li2.innerHTML = "naziv" + this.naziv;
    li3.innerHTML = "tip" + this.tip;
    li4.innerHTML = "cena" + this.cena;
    li5.innerHTML = "kolekcija" + this.kolekcija;

    ul.appendChild(li1);
    ul.appendChild(li2);
    ul.appendChild(li3);
    ul.appendChild(li4);
    ul.appendChild(li5);
    ul.style.fontSize = "20px";
    ul.style.lineHeight = "30px";
    var div3 = document.createElement("div");
    div3.style.border = "2px dashed black";

    div3.appendChild(ul);
    div.appendChild(div1);
    div.appendChild(div3);
    div.style.marginLeft = "60px";
    div3.style.border = "2px dashed black";
    ididv.appendChild(div);
  }
}
class Korpa {
  constructor() {
    this.lista = [];
  }
  dodavanjeuniz(predmet) {
    this.lista.push(predmet);
  }
  brisanjeizniza(predmet) {
    this.lista = this.lista.filter((n) => n.predmet != predmet.id);
  }
  prikazii() {
    this.lista.forEach((element) => {
      element.prikaz();
    });
  }
  sortirajlistu() {
    var gl = document.getElementById("odevnipredmeti");
    while (gl.firstChild != null) {
      gl.removeChild(gl.lastChild);
    }
    this.lista = this.lista.sort((a, b) => a.cena - b.cena);
    this.lista.forEach((element) => {
      element.prikaz();
    });
  }
}

var predmet1 = new Odevnipredmeti(
  "1",
  "sako",
  "https://www.psfashion.com/typo3temp/assets/_processed_/f/4/csm_15940101_o52_3c8482c641.jpg",
  "ps sako",
  "12000",
  "jesen-zima"
);

var predmet2 = new Odevnipredmeti(
  "2",
  "torba",
  "https://cdn11.bigcommerce.com/s-kd54n9g108/images/stencil/original/products/12117/42282/3164106__41792.1695727337.jpg",
  "mona torba",
  "18000",
  "jesen"
);

var predmet3 = new Odevnipredmeti(
  "3",
  "pantalone",
  "https://cdn11.bigcommerce.com/s-kd54n9g108/images/stencil/original/products/12434/42675/8625601_4__69018.1696495947.jpg",
  "pantalone",
  "13000",
  "zima"
);

var predmet4 = new Odevnipredmeti(
  "4",
  "sesir",
  "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBYWFRgVFhIYGBYZGh4cHBkcHBgeHB0cGBwaHhwfHR4eIy4lHx4tIRgdJjgmKy8xNjU1HCU7QDs0Py40NTEBDAwMDw8PEA8RGD8hGB0xMTgxP0AxMT9AMTExMTE8MTE0ODExMTExMTQxMTQxMTExMTExPzQ0Oj81NDo0ND8xP//AABEIARMAtwMBIgACEQEDEQH/xAAcAAEAAQUBAQAAAAAAAAAAAAAAAwECBAYHBQj/xABFEAABAwIDBAcGBAQFAQkBAAABAAIRITEDQVEEEmFxBQYiMoGRoQcTQlLB8GKCsdEjcpLxM0NTouHCFRckRFRjk7LSFP/EABYBAQEBAAAAAAAAAAAAAAAAAAABAv/EABoRAQEAAwEBAAAAAAAAAAAAAAABAhExIRL/2gAMAwEAAhEDEQA/AOzIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIijxMQNBLnBoFySABzJQSItX6S67bNh0a52K7Rgkf1GnlK1zavaJin/DwWNGri559ICDpaLkOL1x255pihnBrGekglQ/9vbY6v/8AW+ODgP0QdkRcTxOm9qFDteL/AFuj9VczrHtY/wDNP8XA/qg7Ui5Fs/XTbGmuIHgfOxv/AEgH1XrbH7QsQR7zAY4Zlji30MoOjotY6P667NiQHOdhu0eKf1CR5wtiwsVrgHNcHNNiCCD4hBKiIgIiICIiAiIgIiICIiDW+snWrC2UFo7eLHcB7uhccuVzyquZ9LdN420OnExN4TRgowRo23CsnjkvPdiFziXOJLnmSSZJhwBmam1eKgL4GgBJjS8zqBvQdLoJ55VJ/pBi/Ex5qjn0PMSBlEUjQEHznNQPdEzO7ffoYyr4G5oQOMqIvIqd4ECj2VBtUsvatjE0NUGQ/GN5EGs3YTN5FW51txNIgMHtHwMb7bVh7YcLfEc1G18mm652ZY4NdU3LHUmNSYHNUc+DNjl2HtdShBeyWnlCCXD2l4OZbzL2mBMB0bw8Qeay8DdfO64CLjIWnPh/ZeYHiaubNLlhNIi7WmP3UjdoGoNbF+k/jNBF1RnzWjpyB9SRw10Vu/YbxEiROVr8KrFOITYTxhzh+gBIv2nFWjFmYM67pDnnhLeywRkDyQeix0xW9qTB05V+88vo7pbFwHB2E97SZplSJBBppdeQzGgxA3gIDAQQy9XGP72AhSseIBBlrKl2RJEU1pmNeUh1Pq912ZikMxwGPNnA9h3Oe6fTityXz7hO7uriaXIBrTTILfOpPWdzS3Z8d0tJ3WPJ7pBgNJ0OWn6QdGREQEREBERAREQEREHzsXyaZ5/8X0B89YsGLJq7dd5h3iLniK6hWYkRmRQkXIzml+Y9VZEikPBuHRwmpEGmtUVeHBt5ZxHaZqeRMatvWVY2DUNBk3wyBOZoS0HzKiGIAY33MJoQ7u1vV1rACHfoquDpLjhscfmB3HVpz8d7NEXvr3iTbv4e8NCJAAmnooi9g7r2CJtiPZXIkNsDCVFd3FbnQ74hsg/MYz8Fa7FI/wAx/GcKRUcGAQgu94KgPbE29++2lQfuqe+Bg77eIGM8nnS/3RUOLSj3f/E62h7NbDirWPJs988GNGmrb8ZVF74NOyY1Zi4h8ydf7KVxI7zSBHxuaxmlN3vADJRM3nfDiOJijnxNbkNcrWjdkxhsNO8ZcbkX3T5cEErHfCA534GAsYL3OYodbWUrMSSAe0RQMZ3W27xtnU1tZY++Dd73iCYaIZAFZsHVzklXGgDSQxt91tXESAf0uKoM1jyMpfE8G5ia2Hn9ZcFwBAFmzvcTxjl6rEY6ggbrKVzIESZyrnqTyVcNwNJhk53PLOJvrAqg7Z1M6XO0bON8ziM7L9T8rvEDzBWxLkfs96TLNpa0mG4oLSDkR3CeMiPzFdcUBERAREQEREBERB80b+YuDp66jmKVVHYgntAjLeaTW0VH1Ci3xYi3pnTMeEqjSZoSTnMmCeIr5goqdjzFHBwk3ForJI7OuSs92B/l5mSwisjVrm1pood4OiWXsaGBw3YM+CHEGbni0zWv5x9UEzqG+I0xNd91bfKZVC9sCHviw7JqDSnY+4VrcXTF1+Q3H4XCn6J7w1/iQMqRQfmof2RF2+TZ2IZ0bHEU3BP6oGgigxdbuiQanLlOStdjTP8AGz0b4mp81TfZ/qOvcFlDStMo/VBWGkf4RIEd4jjQ9oyPXVStw3CYw2NE1J7XiYAn6yog9g+N81+J0XOgjdOik3Gk0w3ONoImoEXJE6zF1RcXmBvPg2IbqDq3tToVdhX7DDM95wrM5C5ImpEWsrGAtmGtbFpdJifw1oao5wmC4uNKCgJvUNqdK6oKmMzvEWgUqLwPIm9FMHH4rCoaPE11PGwULHmBA3RY0rGpFrzU6q5jrkEzmSfWTePLmg9fozaizEa/42ua4flcCByJH3K7zhYgc1rhZwBHIiQvnnZ3R91JuPD9uIXcuqePv7HgmZhm7/QS3/pUHsoiICIiAiIgIiIPl4n0yPIZ/WisfrGvGtNf3KucMtMjl+2Wisgcdfv7KCoeB8R/XKfiH1RmI6NRS0/86WVjncR+nLRHN/Dpl46IJnYpnLPPShu1Wh1x2ONW5/lUQ/c5fpKrXKdLuv5oJt6CIDJ5soRN+zbRSMxHE/Dy85FG1P7LGA/mrxflH7X4q5pzibnO2t/RBkNe+D2x/vqKGZkWVHP1fnFm+F6qExHdHpym5qrmSMgLWsPKI880F7iCMzNpmPWBcyqlxigAFag6eQy+5Vk0vPARbMSJMeOapu/3ccxaa088kEjDXXwsDmKZRNAr2Pm/iBUTn93ULXTqRaLXFRz88lcDU88vu9/Sioz8N4j6zYCQQOJn9czTsXs3xt7YwPlxHCNJh0f7lxfCOVKeQtn6/cHc+gOlcTA2Z78J5G7jMBoCHB7H3/pBQdiRaN0V1+Y6G47N0/M2o8W3Hqtw2PbWYrd7De1zdQf10UGSiIgIojit3g3eG8RIbImBcxpVSoCIiD5cJMfc04+BVk+Gvh/fRer010Pj7M/cx8IsNmH4XRmx4oaSYknUCy8ojIG31n6jRBaPA/cW/cKlBlX665eau3Tp9nzAVs6TSDT78EFSNZieNjlmqROfoL5ZaoHcfpy05Kgdy8/PPRBWlxzHd8cvuFcDFZsdMj+W8q1xp6Z288qq46E+t9D3uSCUGwknL4hevBWxOUzyytqeaoOJHhGVZoLK7emsE1z1mc/2QXP0m0xEm8c9dLkK12sa3+6W4KrtJAMUvStR6jLNW8Y1qdQfT0sgrfX6GsX1Hirg88uA/XyFqKw+JmbW4+KjdiR6UH3RUZLcQAcPCB45rads2tuz7AzCJBx8d4xyz5MINLWF2m9O8BevitGY+ocQIBkNuDzGY4ZrK2jGe8ue4lz3GS43J+8soRU2zdYhMPYRxbUeRXu9HdZ24Tt/Dxi13CfUWPitOb0aSe8B6q8dHAfE70CI6zhe1sNZDtmL8QZ7wY08TRxB8Fg7T7TNrxow8DDYxzzut3QXPk0AbvUn8q5uNlaNfElbB1L6Vbsm14eM5oLBLX0khr6FzeIvykZppXZ+qHV87MwvxTv7TiwcXEJ3ncGhxqWifPhEbMoNmx24jQ9jg5jhLXAyCCp1EEREHD+hvaO8M9xt2C3asEjdJIbvR+IO7L/GDxK9IdVujNu7Ww7X7nEj/BdJE/yPIcB/KYXN9mdD53mtMGC9u8yYpvCDQ2nKVsD+iMDEcXNd7uzmOZ3Z/wDqKiaEHis5ZyX1qY/XEnTHUXbtnknAOI0Dv4JLwIn4Y3wY/D4rWiakaEiNDeM4/wCFvGxdP9KbHAGK3acMR2Xy58DSSHeTnL029eOjNsgbbsfu3f6m7vxyeyHjySZS8qXGzrmQOc5j15FUDKVHD7kW/ddQf7Pti2lu/sO3iCO6SzEAiwpDm+MleBt/s227Dktw2Yok/wCG8bxH8rwyvCStI07++WQ5X4K5orbORBH7W/dZ+0dC7Th0fsu0MianDfHORRefImLm0cb/ADIJG04RrNARx45K8Hx5UArwoR46qNgGQEfUUyH3CrvgfEDGQv8Av9hBUaWvGvHw88kdafGTobU8AMqKzegXA40mlp0ME5qNzhSBnQmkZiP7ILnPzqTE0tIv9ysbEeXO3bDMC8Kj8beoCSdG+tfW4UTcBwMxUeqCfGlgBzz4cFLgvkSvT6v9EnbMbCwRPbeN4/K0VcfBoK6riezHYHOloxcNvysfQ8TvhxnkQqOQMKy9l2DExnbuFhvxHaMa50c4FPFdu2DqDsGHUbMHnXEc5/8Atcd30WyYGA1jQ1jA1os1oAA5AUTY4n0Z7NttxIL2swW6vcC7+lk+pC3Xof2YbLhw7Gc7Hdoewz+lpk+JK31FNjXtq3di3XsYG7MYa9jRAw5o17QLDJw5HVe6x4IBBkESCMwVbtGG1zHNeAWFpDptukVnwWp9TelAHv2M4rcQYZJwntcHBzJtIoSJHqMkG5IiIPlQquBjPYZY8tOcGJ5ixHNVew2v/wAGFFKD1D0y9zQ17d7dIc17CWODgKGKtN7QAvHY2ABKqSrS9SYycW23q5riCHCjhZwMEcjcL3Nh647dggBm2YsDJ5Dxy7YdTkvAkn4fFPdjNVHQNh9rW1so/DwcXkHMd5gkeiz+kPaizEw4d0ewv/8AcLXsHHugnlTmuYBxs0KdmDmalBn9I9Iux3bzsPCZWYYxrB6VIrqsXhMcqXurcJ1SFeXCVVRYrSCN2ujnGvJUbsxPedPAWWdhbBjPHY2fFeD8rHu9Wj1TE2TEw4GLhPYTbfa5pPgQNURDh4QFgpGM3iGiASQATYEmKnIKzEeAsF/SLQaCa+EIPoHqR1Tw9iYZc1+O8dtwsG3DWi+7xzI5AbFjNgr5ewukXB++1xa75m9kjkRUL3cDr90gxwLdrc8DJ7WPB5kje9UH0Zs+JIU64P0d7WNrZDXYWA7juvafIOhWdJ9fdux6e+9035cIbn+6S7/coO37d0hhYLd7FxWYbdXuDZ5Tc8AtI6b9qGBhy3ZmOxnfO6WMHn2neQ5rkWK9znFz3FzjdziSTzJqqK6HsdN9Zdp2sn32KS3LDb2WD8ovzdJV3V7pJ2DiMe01Y4OHGO8OREhedgbG437ImLfRZ2zbK1pmJMm/AIPoTZccPY17TLXNDhycJCLw+ouOXbFhTdu83wa4gekIoOBPrVw/MIIscrf3UeLs00v+sRxr6qQ5w6wz0jOazzUOIakQBwFp+vNFYhwTaeae7A4rIKicSURE9yq3CJqacM/FXsZHNShBYGxYKXCaSQACSaAAEknQAVJXodB9BY+1v93gYZcfieZDGcXuinKpOQK7X1T6l4GxAOA95jkdrFcLTcMHwj1OZVVo3VX2YvxCMXaycNn+kD/Ed/OfgFqd7+VdY2LYmYLG4eExrGNENaBQfuZrJqZWXKqojAxtkL3dsyz5PhPMZ+K4f7UenDjbU5mF/h4H8NoFt6f4hEfi7P5BqurdfOsw2LZyWuHv8SW4Tb1+J5GjQZ0ktGa+fsdod3pJmcySdZ8SqPPILj2nE8Ashmyaw0aZ/dDcrJwsOG0hoPiYn9gLDMLIwcP5Rb4nRGdqx65WUGA3ZBEijdTY2n7Co/D3alpj5svvwXqbkxHbdTtViYyHjbylVDN6/aJkfhvnwVV4zCJmaLNbjiBxtFZU+J0e2Zu75RQBXM2GNC4507P39EELcSSaUGf0WXszLSeJpb7qrsPZRlVovA7xqFO3CIuKuiYNm/YhBkYD53eJJ5c/NTsNuZP35rEYbnLut/fl+yyWNiYyEDmeOWSI617Nx/4McXv/AFVFm9StmLNiwQRBLS7+txcPQhFBwDaDND2ozFSKZzUHz/fEc4T3p8p/dZbgBAILSdYiopQ08iT9MPaWwZibVGmVDXP15oK4joCiwXyOIUjrLHw2gPbvO3GFwDnQTutJG87dF4FYzhBkswnOc1rWlznGGtaCSToAKkrpPVT2YOfGJthLGXGC09o/zOHdHAV4hb11V6q7NsbA7CG+9wBOM6C5wIFjZrTo31WyIMbYNhw8Fgw8JjWMbZrRA58TxWTCKHatpZhtc/Ee1jGiXOcQABxJQSrVOtXXjZ9jDmA+92iKYTTYxTfPwjhU8FpPW/2lPxN7C2IljLHGIh7v5Ae6PxHtabq5sQZmSSTJOZJuTqZQet0707i7XiHFx3S6IaBRrG33WjSvM5rADbafqKzeh01uoWmuppTxhZOFhxzpUzWJgjM1k0juqquY3RskZmYNo43i8RCkEE1JecrBsRnlqZGg1VjIsZdSkfWMwJvWqnnUgNrEEkm0iQOEUH1UQ3aw4wT8IEGooDneDWlCpN38gNRqfuki6twW/C1sGKGBM8vXwtRSsIM7suIEnQSTEnK2c1VVdhsBmOy2x14X50nwU/uxFobcnUH78bco2iT2jvPJo2KVj+1dVJvQakF1gBECRprS/wCmRFNwCuWTc5FONfvRCw2+I940MVy9BdSETA7z4qcgD9BfWvnaWT2RWe8Tc8J8eFAiqYTZMgdkUHE/t+xXo9FdHOxsVmA27nDepMAzvE8hJ8AsRlMhSgH38VPCF0n2d9B7jTtL29t4hkioabnxsOA4ojdcLDDWtaBAaAAOAEBVUiKD5lbPwuBmlR9RIInSLnxx9ow5EFpZyqOHC/3VZDgayzXtNBrpVtD4wrGtp2cShuIzPFtBXmisHCmKqPGZKlxxuPkiJoYqPE0z4Zo5qI697HusvvcE7FiH+JgCWTd2FMAc2khvItXS18rbD0k/ZsZmPhO3cRhkcRm1w+Uih5rdesPtK2jam7uBOzYVnbp/iOpWXjuDg2tL5IOi9aevmz7HvMB99jj/ACmGx/G6oZyqeC4z1j6y7Ttr97GxOyD2MNshjOTc3fiMnkKLzIVj3ht1VUCoHyd1tTrkJP8AyopLzbdbxnK8lT4WCIoa6QKg5SJrKiJNmYam0RJvWamnOLrJw4pQumm6LTPkRZtTmqbhFdwmBd1ZGRBmlqR9Vc6gq4BpsBBkETQnsmCQLSiqunukwNL5+QrlwV7Lkht47TicpIMms8/NWMw5FBOUuJAqJitRQHLPipXOiS95N6AQRvAXzOdLUCCrQJgklxgboFzeCLG0VjMqVjjAJIa00oawBTxra4UWGDEBoYBJjMSImOQAubq9rgTLe24XMgiYm5oItFVROwU7EAVIdqCbgZigvTgpA2QQ2IqS41m9puMp4KGsw7tAWa2toyJvnX6qXcHx0izRWtcga8hzoiLmCWkNcQ2va1NaA51F6XCngAWAaPWTxrnaZtwCkaBANibARJMmchJpxpotn6pdU3bQRjYvZwQTDQauIdWojOQZGSCHqb1XdtDhi4gLcFhHN5FwDpqRyC6wxoAAAgAQALABW4GE1jQ1rQ1rRAAEAAaKZQEREHzI2N7suIOhkm08HeapJIkta6LHszTyApzUhkxvBrxpnQRQO/8A1krIb8r2Gxv9RA+9EVFiMafmAtWo4zvc1hHAeab4iPhqTHEfReiLwMQEUyOVIoSPRVe1xIBY0wdQPOQNaTog8l2wx8J5z5nioMM7hkTFjK9d+HluOFLi1PHgPsrHfhCsl2WUnzIrdEQ4m0ZNBJ1i37lWYWzEmSC48f72WR7oA3P9OX9OWqyMNgv2jXKW1HGKXCC3D2Y2AbMSK8PHyUwEXe0DKKUkGmouY1KtDD8jzzM1ubm9LcSpBhnJjeFa/MCKXrZFWy2+853KBeYgt/RVEjshgqJkxUQD4meIVS4/E9oHClRQ1NoFPRU93IiHuBrnFIo5p3WmxkjVBUvBmXFxGlrChit/mOSvw2EUADPxG4EibUymp0VQ07snda2Y1M3IJo3IUqqsc0EQ0uMyC6KHgLamgQUawO/Hci26JkcADEWm9ll7ubnRSYbnNBXPKwyU2w9HY2KQGMc6oMNmBAjvVLTOVFunQ3s7c6HYp3BmBIJ5wbzJug0jAJmGticxG8Z+pE3Pgtg6G6n7TiwWs3GmJe7s0zAzivdAgxddQ6L6ubPgRu4YLvmIE/dF7KI1boDqZg7Od9597iHMjsgzPZbYLaGiKAQrkQEREBERBwrpLqXteEa7M5za9rDJcK6tbJiguFr+JhPZQhzDEEObuxB0FPRfSqixcJrhDmhw0IBHqg+bHzMFrTEH4agxrBTdg/4ZANKEi38pMnl9F37aOrGxvq7ZMKdWtDT5tgryto9nmwvthuZWey91x/NKK4iGQJh9jqajMAjhZC0fM4CtCxsicrfcLsWJ7M9mNsbGF82G/wCWyg/7sML/ANTiZ3Ascr2QclJr3zP8rZIp6j6oSPnfFu63K1Y+4XVz7L8M32rEIiO6JPjKmb7MsDPaMU8t0V1sa0QciZBzca5A5adnha6kpPddU5k3GdXAea7Hh+zbYxc4rpvLx9Ghejs/UrYWW2ZprPac91Ra5hBwtrTEBjQKVAjtQCLNpax0XobJ0JtG0RuYWI6YMtbA49qv68V3fZuhdmw6s2bCadQxoPnEr0ERyDo32bbQ4D3rmsF6u3nzEGua23oz2e7NhjtbzzoSQ2eS3NEGNsuxYeG0Nw8NrGiwaAFkoiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIg/9k=",
  "haljina",
  "5000",
  "leto"
);
var predmet5 = new Odevnipredmeti(
  "5",
  "haljina",
  "https://cdn11.bigcommerce.com/s-kd54n9g108/images/stencil/original/products/12303/42818/54255001_2__81154.1696497887.jpg",
  "haljina",
  "4000",
  "zima"
);

var nozpredmeta = new Korpa();
nozpredmeta.dodavanjeuniz(predmet1);
nozpredmeta.dodavanjeuniz(predmet2);
nozpredmeta.dodavanjeuniz(predmet3);
nozpredmeta.dodavanjeuniz(predmet4);
nozpredmeta.dodavanjeuniz(predmet5);
nozpredmeta.prikazii();
