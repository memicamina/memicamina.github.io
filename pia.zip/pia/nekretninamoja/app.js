class Nekretnina {
  constructor(id, naziv, slika, tip, cena, lokacija, povrsina) {
    this.id = id;
    this.naziv = naziv;
    this.slika = slika;
    this.tip = tip;
    this.cena = cena;
    this.lokacija = lokacija;
    this.povrsina = povrsina;
  }
  prikazi(id) {
    var div = document.createElement("div");
    div.style.border = "2px solid black";
    div.style.width = "500px";
    div.style.margin = "20px";
    div.style.padding = "20px";

    var img = document.createElement("img");
    img.src = this.slika;
    img.style.width = "500px";
    img.style.height = "300px";
    var img1 = "nek.jpg";
    var img2 = "gray.jpg";

    var div1 = document.createElement("div");
    div1.style.width = "500px";
    div1.style.height = "300px";

    div1.appendChild(img);

    div1.addEventListener("mouseover", mouseOver);
    function mouseOver() {
      img.src = img2;
    }

    img.addEventListener("mouseout", mouseOut);
    function mouseOut() {
      img.src = img1;
    }

    var ul = document.createElement("ul");
    ul.style.fontSize = "20px";
    ul.style.lineHeight = "30px";
    var li1 = document.createElement("li");
    var li2 = document.createElement("li");
    var li3 = document.createElement("li");
    var li4 = document.createElement("li");
    var li5 = document.createElement("li");
    var li6 = document.createElement("li");

    li1.innerHTML = "Id: " + this.id;
    li2.innerHTML = "Naziv: " + this.naziv;
    li3.innerHTML = "Tip: " + this.tip;
    li4.innerHTML = "Cena: " + this.cena;
    li5.innerHTML = "Lokacija: " + this.lokacija;
    li6.innerHTML = "Površina: " + this.povrsina;

    ul.appendChild(li1);
    ul.appendChild(li2);
    ul.appendChild(li3);
    ul.appendChild(li3);
    ul.appendChild(li4);
    ul.appendChild(li5);
    ul.appendChild(li6);

    div.appendChild(div1);
    div.appendChild(ul);
    var divId = document.getElementById(id);
    divId.appendChild(div);
  }
}

class ListNekretnina {
  constructor() {
    this.nizNekretnina = [];
  }

  dodavanjeuniz(id) {
    this.nizNekretnina.push(id);
  }
  brisanjeniz(id) {
    for (var i = 0; i < this.nizNekretnina.length; i++) {
      if (this.nizNekretnina[i].id == id - 1) {
        this.nizNekretnina.splice(this.nizNekretnina[i].id, 1);
      }
    }
  }

  prikaziniz() {
    for (var i = 0; i < this.nizNekretnina.length; i++) {
      this.nizNekretnina[i].prikazi("nekretnina");
    }
  }
}

var nek1 = new Nekretnina(
  "1",
  "dvosoban stan",
  "nek.jpg",
  "stan",
  "400",
  "novi pazar",
  "stevane nemanje"
);

var nek2 = new Nekretnina(
  "1",
  "dvosoban stan",
  "nek.jpg",
  "stan",
  "400",
  "novi pazar",
  "stevane nemanje"
);

var nek4 = new Nekretnina(
  "4",
  "Dvosoban stan",
  "nek.jpg",
  "Stan",
  "40000€",
  "Novi Pazar",
  "Stevan Nemanja 12"
);

var nek5 = new Nekretnina(
  "5",
  "Dvosoban stan",
  "nek.jpg",
  "Stan",
  "40000€",
  "Novi Pazar",
  "Stevan Nemanja 12"
);

var nizNekretnina = new ListNekretnina();
nizNekretnina.dodavanjeuniz(nek1);
nizNekretnina.dodavanjeuniz(nek2);
nizNekretnina.dodavanjeuniz(nek4);
nizNekretnina.dodavanjeuniz(nek5);
nizNekretnina.brisanjeniz(3);
nizNekretnina.prikaziniz();
