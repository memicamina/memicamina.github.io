class Destinacija {
    constructor(id,naziv,slika1,sliak2,cena,lokacija,tipprevoza,brojdana,brojslobodnih,datumpolaska,odlaska){
      

        this.id =id;
        this.naziv = naziv;
        this.slika1=slika1;
        this.sliak2=sliak2;
        this.cena =cena;
        this.lokacija =lokacija;
        this.tipprevoza = tipprevoza;
        this.brojdana = brojdana;
        this.brojslobodnih = brojslobodnih;
        this.datumpolaska=datumpolaska;
        this.odlaska =odlaska;
  }

    prikazi(id){
        var div = document.createElement('div');
        var img = document.createElement('img');    
        img.src=this.slika1;
        var img1=this.slika1;
        var img2=this.sliak2;
        img.addEventListener('mouseover',mouseOver)
        img.addEventListener('mouseout',mouseOut)
        function mouseOver(){
            img.src=img2;
        }
        function mouseOut(){
            img.src=img1
        }
        var ul = document.createElement('ul');
        var li1 = document.createElement('li');
        var li2 = document.createElement('li')
        var li3 = document.createElement('li')
        var li4 = document.createElement('li')
        var li5 = document.createElement('li')
        var li6 = document.createElement('li')
        var li7 = document.createElement('li')
        var li8 = document.createElement('li')

        li1.innerHTML='naziv' + this.naziv;
        li2.innerHTML='cena' + this.cena;
        li3.innerHTML = 'Lokacija: ' + this.lokacija
        li4.innerHTML = 'Tip prevoza: ' + this.tipPrevoza
        li5.innerHTML = 'Broj dana: ' + this.brojDana
        li6.innerHTML = 'Broj slobodnih mesta: ' + this.brojSlobodnihMesta
        li7.innerHTML = 'Datum polaska: ' + this.datumPolaska
        li8.innerHTML = 'Datum odlaska: ' + this.datumOdlaska

        ul.appendChild(li1);
        ul.appendChild(li2)
        ul.appendChild(li3)
        ul.appendChild(li4)
        ul.appendChild(li5)
        ul.appendChild(li6)
        ul.appendChild(li7)
        ul.appendChild(li8)
        div.appendChild(img);
        div.appendChild(ul);
        var iddiv = document.getElementById(id);
        iddiv.appendChild(div);
    }
}

class turistickaagencija{
    constructor(){
        this.niz=[]
    }
    dodavanje(id){
        this.niz.push(id);
    }

    brisanjedestinacija(id){
        for(var i = 0; i< this.niz.length; i++){
            if(this.niz[i] == id -1){
                this.niz.splice(this.niz[i].id,1)
            }
        }
    }
    prikazilistu(){
        for(var i = 0;i <this.niz.length;i++){
            this.niz[i].prikazi('destinacija')
        }
    }
}

var des1 = new Destinacija(
    '1',
    'Vrnjacka banja',
    'slika1.jpg',
    'slika2.jpg',
    '2500 dinara',
    'Vrnjacka banja',
    'Autobus',
    '3 dana',
    '8 mesta',
    '18.11.2021. godine',
    '21.11.2021. godine'
  )
  var des2 = new Destinacija(
    '2',
    'Vrnjacka banja',
    'slika1.jpg',
    'slika2.jpg',
    '2500 dinara',
    'Vrnjacka banja',
    'Autobus',
    '3 dana',
    '8 mesta',
    '18.11.2021. godine',
    '21.11.2021. godine'
  )
  var des3 = new Destinacija(
    '3',
    'Vrnjacka banja',
    'slika1.jpg',
    'slika2.jpg',
    '2500 dinara',
    'Vrnjacka banja',
    'Autobus',
    '3 dana',
    '8 mesta',
    '18.11.2021. godine',
    '21.11.2021. godine'
  )
  var des4 = new Destinacija(
    '4',
    'Vrnjacka banja',
    'slika1.jpg',
    'slika2.jpg',
    '2500 dinara',
    'Vrnjacka banja',
    'Autobus',
    '3 dana',
    '8 mesta',
    '18.11.2021. godine',
    '21.11.2021. godine'
  )
  var des5 = new Destinacija(
    '5',
    'Vrnjacka banja',
    'slika1.jpg',
    'slika2.jpg',
    '2500 dinara',
    'Vrnjacka banja',
    'Autobus',
    '3 dana',
    '8 mesta',
    '18.11.2021. godine',
    '21.11.2021. godine'
  )

  var listades = new turistickaagencija();
  listades.dodavanje(des1);
  listades.dodavanje(des2);
  listades.dodavanje(des3);
  listades.dodavanje(des4);
  listades.dodavanje(des5);
  listades.brisanjedestinacija('3');
  listades.prikazilistu()