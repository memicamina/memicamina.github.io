
class Automobil{
    
    constructor(naziv, brojvrata, kubikaza, godiste, cena)
    {
        this.naziv = naziv;
        this.brojvrata = brojvrata;
        this.kubikaza = kubikaza;
        this.godiste = godiste;
        this.cena = cena;
    }
}

class listaautomobila{
    constructor(){
        this.lista=[];
    }
    dodajauto(auto){
        this.lista.push(auto);
    }
    brisi(auto){
        for(var i = 0;i< this.lista.length; i++){
            if(this.lista[i].auto == auto-1){
                this.lista.splice(this.lista[i].auto,1);
            }
        }
    }
    prikazi(){
        var glavni = document.getElementById('glavni');
      
        var t = "";
        t +="<table border=1>";
        t += "<tr><th>Naziv</th>";
        t += "<th>Broj vrata</th>";
        t += "<th>Kubikaza</th>";
        t += "<th>Godiste</th>";
        t += "<th>Cena</th>";
        t += "<th ></th></tr>";
        for(let i =0;i< this.lista.length;i++){
            t +="<tr><th>" + this.lista[i].naziv + "</th>";
            t +="<th>" + this.lista[i].brojvrata + "</th>";
            t +="<th>" + this.lista[i].kubikaza + "</th>";
            t +="<th>" + this.lista[i].godiste + "</th>";
            t +="<th>" + this.lista[i].cena + "</th>";
            t +="<th>detalji</th>";
            t +="</tr>"
        }
        t +="</table>";
        t +="<button  onclick='aautomobili.sortirajpoceni()'>sortiraj po ceni</button>"
        t +="<button  onclick='aautomobili.sortirajpokub()'>sortiraj po kubikazi</button>"
      glavni.innerHTML=t;
      glavni.appendChild(btn1);

    }
    sortirajpoceni(){
       while(glavni.firstChild != null){
        glavni.removeChild(glavni.lastChild);
        this.lista= this.lista.sort((a,b) => a.cena - b.cena);
        this.prikazi()
       }
    }
    sortirajpokub(){
       
        while(glavni.firstChild != null){
            glavni.removeChild(glavni.lastChild);
            this.lista = this.lista.sort((a,b) => a.kubikaza.localeCompare(b.kubikaza));
            this.prikazi();
        }
    }


}

auto1= new Automobil("bmw", "6","1.9","2001",400);
auto2= new Automobil("bmw", "6","1.9","2001",600);
auto3= new Automobil("bmw", "6","1.9","2001",200);
auto4= new Automobil("bmw", "6","1.9","2001",4000);
auto5= new Automobil("bmw", "5","4.9","2001",100);
aautomobili = new listaautomobila();
aautomobili.dodajauto(auto1);
aautomobili.dodajauto(auto2);
aautomobili.dodajauto(auto3);
aautomobili.dodajauto(auto4);
aautomobili.dodajauto(auto5);
aautomobili.prikazi();