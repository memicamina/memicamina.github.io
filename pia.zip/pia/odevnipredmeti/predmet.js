class Odevnipredmeti {
  constructor(id, naziv, slika, tip, cena, kolekcija) {
    this.id = id;
    this.naziv = naziv;
    this.slika = slika;
    this.tip = tip;
    this.cena = cena;
    this.kolekcija = kolekcija;
  }
  prikaz() {
    var iddiv = document.getElementById("odevnipredmeti");
    var div = document.createElement("div");
    div.style.border = "2px solid black";
    div.style.width = "500px";
    div.style.margin = "20px";
    div.style.padding = "20px";

    var img = document.createElement("img");
    img.src = this.slika;
    img.style.width = "500px";
    img.style.height = "300px";

    var div1 = document.createElement("div");
    div1.style.width = "500px";
    div1.style.height = "300px";
    div1.style.border = "2px solid black";

    div1.appendChild(img);
    var ul = document.createElement("ul");
    ul.style.fontSize = "20px";
    ul.style.lineHeight = "30px";

    var li1 = document.createElement("li");
    var li2 = document.createElement("li");
    var li3 = document.createElement("li");
    var li4 = document.createElement("li");
    var li5 = document.createElement("li");

    li1.innerHTML = "id" + this.id;
    li2.innerHTML = "naziv" + this.naziv;
    li3.innerHTML = "tip" + this.tip;
    li4.innerHTML = "cena" + this.cena;
    li5.innerHTML = "kolekcija" + this.kolekcija;
    ul.appendChild(li1);
    ul.appendChild(li2), ul.appendChild(li3);
    ul.appendChild(li4);
    ul.appendChild(li5);
    var div3 = document.createElement("div");
    div3.style.border = "2px dashed black";
    div3.appendChild(ul);
    div.appendChild(div1);
    div.appendChild(div3);
    div.style.marginLeft = "100px";
    iddiv.appendChild(div);
  }
}

class Korpa {
  constructor() {
    this.lista = [];
  }
  dodavanjeuniz(predmet) {
    this.lista.push(predmet);
  }
  brisanjeizniza(predmet) {
    this.lista = this.lista.filter((n) => n.predmet != predmet.id);
  }
  prikazii() {
    this.lista.forEach((element) => {
      element.prikaz();
    });
  }
  sortirajlistu() {
    var gl = document.getElementById("odevnipredmeti");
    while (gl.firstChild != null) {
      gl.removeChild(gl.lastChild);
    }
    this.lista = this.lista.sort((a, b) => a.cena - b.cena);
    this.lista.forEach((element) => {
      element.prikaz();
    });
  }
}

var predmet1 = new Odevnipredmeti(
  "1",
  "HALJINA",
  "https://gradskeinfo.rs/wp-content/uploads/2022/05/woman-gbff72ab02_640.jpg",
  "haljina",
  "20220",
  "leto"
);

var predmet2 = new Odevnipredmeti(
  "1",
  "HALJINA",
  "https://gradskeinfo.rs/wp-content/uploads/2022/05/woman-gbff72ab02_640.jpg",
  "haljina",
  "220",
  "leto"
);

var predmet3 = new Odevnipredmeti(
  "1",
  "HALJINA",
  "https://gradskeinfo.rs/wp-content/uploads/2022/05/woman-gbff72ab02_640.jpg",
  "haljina",
  "120",
  "leto"
);

var predmet4 = new Odevnipredmeti(
  "1",
  "HALJINA",
  "https://gradskeinfo.rs/wp-content/uploads/2022/05/woman-gbff72ab02_640.jpg",
  "haljina",
  "20",
  "leto"
);
var predmet5 = new Odevnipredmeti(
  "1",
  "HALJINA",
  "https://gradskeinfo.rs/wp-content/uploads/2022/05/woman-gbff72ab02_640.jpg",
  "haljina",
  "7720220",
  "leto"
);

var nozpredmeta = new Korpa();
nozpredmeta.dodavanjeuniz(predmet1);
nozpredmeta.dodavanjeuniz(predmet2);
nozpredmeta.dodavanjeuniz(predmet3);
nozpredmeta.dodavanjeuniz(predmet4);
nozpredmeta.dodavanjeuniz(predmet5);
nozpredmeta.prikazii();
