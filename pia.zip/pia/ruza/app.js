class Biljka {
  constructor(id, naziv, slika, latinskinaziv, opis) {
    this.id = id;
    this.naziv = naziv;
    this.slika = slika;
    this.latinskinaziv = latinskinaziv;
    this.opis = opis;
  }

  prikazi(id) {
    var div = document.createElement("div");
    div.style.border = "2px solid black";
    div.style.width = "500px";
    div.style.margin = "20px";
    div.style.padding = "20px";

    var img = document.createElement("img");
    img.src = this.slika;
    img.style.width = "500px";
    img.style.height = "300px";
    var div1 = document.createElement("div");
    div1.style.width = "500px";
    div1.style.height = "300px";

    div1.appendChild(img);
    var p = document.createElement("p");
    p.innerHTML = "kratak opis" + this.opis;
    div.appendChild(div1);
    div.appendChild(p);
    var iddiv = document.getElementById(id);
    iddiv.appendChild(div);
  }
}

class ListaBiljaka {
  constructor() {
    this.nizBiljaka = [];
  }
  dodavanjeuniz(id) {
    this.nizBiljaka.push(id);
  }
  prikaziniz() {
    for (var i = 0; i < this.nizBiljaka.length; i++) {
      this.nizBiljaka[i].prikazi("biljka");
    }
  }
}
var bilj1 = new Biljka("1", "ruza", "ruza.jpg", "ljkajgdgh", "Ruza crvena");
var nizBiljaka = new ListaBiljaka();

var bilj2 = new Biljka("2", "ruza", "ruza.jpg", "jahdjka", "Ruza crvena");
var nizHerbarijum = new ListaBiljaka();
nizBiljaka.dodavanjeuniz(bilj1);
nizBiljaka.dodavanjeuniz(bilj2);
nizBiljaka.prikaziniz();
