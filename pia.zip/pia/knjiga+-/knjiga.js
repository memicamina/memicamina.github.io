class Knjiga {
  constructor(id, naziv, isbn, godina, autor, izdavac, opis, urlSlike) {
    this.id = id;
    this.isbn = isbn;
    this.naziv = naziv;
    this.godina = godina;
    this.autor = autor;
    this.izdavac = izdavac;
    this.opis = opis;
    this.urlSlike = urlSlike;
  }
  prikaz(id) {
    var glavni = document.getElementById(id);
    var naziv = document.createElement("div");
    var p = document.createElement("p");
    var btn = document.createElement("button");
    btn.innerHTML = "+";
    btn.style.height = "30px";
    btn.style.marginLeft = "100px";

    p.innerHTML = this.naziv;
    naziv.style.display = "flex";
    naziv.appendChild(p);
    naziv.appendChild(btn);
    glavni.appendChild(naziv);
    var detalji = document.createElement("div");
    var detalji1 = document.createElement("div");
    var detalji2 = document.createElement("div");
    var img = document.createElement("img");
    img.style.height = "100px";
    img.style.width = "100px";
    var p1 = document.createElement("p");
    var p2 = document.createElement("p");
    var p3 = document.createElement("p");
    var p4 = document.createElement("p");
    var p5 = document.createElement("p");
    img.src = this.urlSlike;
    p1.innerHTML = this.isbn;
    p2.innerHTML = this.godina;
    p3.innerHTML = this.autor;
    p4.innerHTML = this.izdavac;
    detalji1.appendChild(img);
    detalji1.appendChild(p1);
    detalji1.appendChild(p2);
    detalji1.appendChild(p3);
    detalji1.appendChild(p4);
    p5.innerHTML = this.opis;
    detalji2.style.marginLeft = "50px";
    detalji2.appendChild(p5);
    detalji.appendChild(detalji1);
    detalji.appendChild(detalji2);
    glavni.appendChild(detalji);
    detalji.style.display = "flex";

    btn.onclick = () => {
      if (btn.innerHTML == "+") {
        detalji.style.display = "flex";
        btn.innerHTML = "-";
        glavni.style.border = "0";
      } else {
        detalji.style.display = "none";
        btn.innerHTML = "+";
      }
    };
    glavni.style.border = "2px solid black";
    glavni.style.height = "300px";
    glavni.style.width = "270px";
    img.style.border = "2px";
    detalji2.style.border = "2px solid black";
    detalji2.style.width = "100px";
    detalji2.style.height = "230px";
    detalji1.style.lineHeight = "10px";
    glavni.style.margin = "20px";
    glavni.style.gap = "20px";
  }
}
prvaknjiga = new Knjiga(
  1,
  "Ana Karenjina",
  "1",
  "1873",
  "Tolstoy",
  "IKM",
  "Sve srećne porodice liče jedna na drugu, svaka nesrećna porodica nesrećna je na svoj način.",
  "https://24sedam.rs/data/images/2023-06-21/447633_profimedia-0753635769_orig.jpg"
);
prvaknjiga.prikaz("glavni");

prvaknjiga1 = new Knjiga(
  1,
  "Gordost i predrasuda",
  "22",
  "2009",
  "Danijela Stil",
  "IKM",
  "Čovek može biti gord, a ne biti sujetan. Gordost se više odnosi na naše mišljenje o nama, sujeta na ono što bismo hteli da drugi misle o nama.",
  "https://www.knjizare-vulkan.rs/files/images/slike_proizvoda/239315.jpg"
);
prvaknjiga1.prikaz("glavni1");

prvaknjiga1 = new Knjiga(
  1,
  "Kuca",
  "32",
  "2009",
  "Danijela Stil",
  "IKM",
  "Jednom... kad budem ja ko ptica bijela..",
  "https://salonknjiga.rs/wp-content/uploads/2019/01/knjige.jpg"
);

prvaknjiga1.prikaz();
