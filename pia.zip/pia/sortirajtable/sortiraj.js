class Artikal{
    constructor(sifra,naziv,slika,cena,stanje){
        this.sifra=sifra;
        this.naziv =naziv;
        this.slika=slika;
        this.cena=cena;
        this.stanje =stanje;
    }
    validacija(){
        if(this.sifra == null || this.naziv == null || this.cena== null){
            return 0;
        }
        else{
            return 1;
        }
    }
}

class ListaArtikala{
    constructor(){
        this.artikli=[];
    }
    dodaj(artikal){
        this.artikli.push(artikal)
    }
    sortirajpoceni(){
        this.artikli.sort((a,b)=> a.cena - b.cena);
        var trenutni=document.getElementById('glavni');
        trenutni.removeChild(trenutni.lastChild);
        this.prikaz();
    }
    sortirajposifri(){
        this.artikli.sort((a,b)=> b.sifra - a.sifra);
        var trenutni = document.getElementById('glavni');
        trenutni.removeChild(trenutni.lastChild);
        this.prikaz();
    }
    prikaz(){
        var div = document.getElementById("glavni");
        var div2=document.createElement("div");
        var t ="";
        t+="<table border=1>"
        t+="<tr>";
        t+="<td>sifra</td>";
        t+="<td>naziv</td>";
        t+="<td>cena</td>";
        t+="<td>stanje</td>";
        t+="</tr>";
        for(var i = 0; i<this.artikli.length; i++){
            t+="<tr>"
            t+="<td>" + this.artikli[i].sifra + "</td>";
            t+="<td>" + this.artikli[i].naziv + "</td>";
            t+="<td>" + this.artikli[i].cena + "</td>";
            t+="<td>" + this.artikli[i].stanje + "</td>";
        }
        t+="</table>";
        div2.innerHTML=t;
        div.appendChild(div2);
    }
}
proizvod1=new Artikal("2","hleb","nista","120","522");
proizvod2=new Artikal("4","cokolada","nista","100","45");
proizvodi= new ListaArtikala();
proizvodi.dodaj(proizvod1);
proizvodi.dodaj(proizvod2);
proizvodi.prikaz();
