

import pandas as pd
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression

# Podaci o nekretninama
data = {
    'area': [122.07, 91.70, 157.01, 83.80, 126.35, 91.60, 75.81, 137.40, 257.81, 154.59, 171.87],
    'price': [207500, 94500, 181000, 125500, 187500, 102000, 124500, 130500, 325000, 172400, 248000]
}

# Kreiranje DataFrame-a
df = pd.DataFrame(data)

# Izdvajanje atributa i ciljnog atributa
X = df[['area']]
y = df['price']

# Inicijalizacija modela linearne regresije
model = LinearRegression()

# Treniranje modela
model.fit(X, y)

# Koeficijenti linearne regresije
w0 = model.intercept_
w1 = model.coef_[0]

# Izračunavanje predikcija
predicted_y = model.predict(X)

# Prikazivanje grafika
plt.scatter(X, y, label='Real estate prices')
plt.plot(X, predicted_y, color='red', label='Regression line')
plt.xlabel('Area (m^2)')
plt.ylabel('Price ($)')
plt.title('Real Estate Prices Prediction')
plt.legend()
plt.show()