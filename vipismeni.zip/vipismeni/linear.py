import pandas as pn
import matplotlib.pyplot as plt
from sklearn import linear_model

x= [[4.0],[4.5],[5.0],[5.6],[5.8],[6.0],[7.2],[7.4],[7.8],[9]]
y = [42,45,50,55,58,62,65,70,72,75]

regression = linear_model.LinearRegression()
regression.fit(x,y)
#Koeficijenti linearne regresije
w0= regression.intercept_
w1= regression.coef_[0]


minx = min(x)[0]
maxx = max(x)[0]


predicted_min_y = w1*minx + w0
predicted_max_y = w1*maxx + w0

#Prikazujemo liniju regresije.
plt.plot([minx,maxx],[predicted_min_y,predicted_max_y])
#Prikazi mi kruzice na mapi za x i y koord.
plt.scatter(x,y)
plt.xlabel('Pizza size')
plt.ylabel('pizza price')
plt.show()