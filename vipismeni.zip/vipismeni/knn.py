

from math import sqrt
import numpy as np
import matplotlib.pyplot as plt

#0-False,1-True
dataset = [
    [7,2,0],
    [5,4,0],
    [3,2,1],
    [8,4,1],
    [8,3,1],
    [1,3,0]
]
new_data = [4,9]

def Euclidean_distance(first,second):
      return sqrt(((first[0] - second[0]) ** 2) + ((first[1] - second[1])**  2))

def Get_Neighbors(dataset, new_data, k):
    distance = list() # []
    data = []
    for i in dataset:
        dist = Euclidean_distance(new_data, i)
        distance.append(dist)
        data.append(i)
    distance = np.array(distance)
    data = np.array(data)
    index_dist = distance.argsort()
    data = data[index_dist]
    neighbors = data[:k]
    return neighbors
def predict_classification(dataset, new_data, k):
    Neighbors = Get_Neighbors(dataset, new_data, k)
    Classes = []
    for i in Neighbors:
        Classes.append(i[-1])
    prediction = max(Classes, key= Classes.count)
    return prediction

print(Get_Neighbors(dataset,new_data,3))
neighbour = Get_Neighbors(dataset, new_data, 3)

prediction = predict_classification(dataset, new_data, 3)
print('Novi element pripada klasi:',prediction)

colors = ['red']+['green']+['red']+['blue']

#print([col[1] for col in neighbour])
plt.scatter([col[1] for col in neighbour]+[new_data[1]],[col[0] for col in neighbour]+[new_data[0]],c=colors)
plt.text(x=new_data[0]+3.4,y=new_data[1]-4.7,s=f" new_data : class {prediction}")
plt.xlabel('P2',fontsize = 20)
plt.ylabel('P1',fontsize = 20)
plt.show()