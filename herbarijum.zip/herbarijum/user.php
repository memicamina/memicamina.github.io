<?php
include 'connect.php';

if(isset($_POST['submit'])){
    $naziv = $_POST['naziv'];
    $slika = $_POST['slika'];
    $latinskinaziv = $_POST['latinskinaziv'];
    $opis = $_POST['opis'];

    $sql = "INSERT INTO `biljka` (naziv, slika, latinskinaziv, opis) VALUES ('$naziv', '$slika', '$latinskinaziv', '$opis')";

    $result = mysqli_query($con, $sql);

    if($result){
        //echo "Data inserted successfully";
        header('location:display.php');
    } else {
        die(mysqli_error($con));
    }
}
?>

<!doctype html>

  <head>


    <title>Biljka</title>
  </head>
  <body>
    <div >
<form method="post">
    <form>
  <div>
    <label>Naziv</label>
    <input type="text"  placeholder="Enter your name" name="naziv" >
</div>
<div>
    <label >slika</label>
    <input type="text" placeholder="Enter your email" name="slika" >
</div>
 <div >
    <label >Latinski naziv</label>
    <input type="text" placeholder="Enter your mobile number" name="latinskinaziv">
</div > <div>

    <label >Opis</label>
    <input type="text" placeholder="Enter your name" name="opis">
</div>


   
 
<button  name="submit" style="color: white;">Submit</button>
</form>
</div>
 

  </body>
</html>