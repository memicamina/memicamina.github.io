<?php

$con = mysqli_connect('localhost', 'root','','herbarijum');

if(!$con){

die(mysqli_error($con));
}

?>