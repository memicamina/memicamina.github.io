<?php
include 'connect.php';
?>

<!doctype html>
<head>
  
    <title>biljka</title>
</head>
<body>
    <div>
       
        <table>
            <thead>
                <tr>
                    <th scope="col">Naziv</th>
                    <th scope="col">Slika</th>
                    <th scope="col">Latinski naziv</th>
                    <th scope="col">Opis</th>
                   
                </tr>
            </thead>
            <tbody>

                <?php

                $sql = "SELECT * FROM `biljka`";
                $result = mysqli_query($con, $sql);

                if ($result) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        $naziv = $row['naziv'];
                        $slika = $row['slika'];
                        $latinskinaziv= $row['latinskinaziv'];
                        $opis = $row['opis'];
                        

                        echo '<tr>
                            <th scope="row">' . $naziv . '</th>
                            <td>' . $slika . '</td>
                            <td>' . $latinskinaziv. '</td>
                            <td>' . $opis . '</td>
                            
                            <td>
                                <a href="delete.php?deleteid=' . $naziv . '">Delete</a>
                            </td>
                        </tr>';
                    }
                }

                ?>

            </tbody>
        </table>
    </div>
</body>
</html>